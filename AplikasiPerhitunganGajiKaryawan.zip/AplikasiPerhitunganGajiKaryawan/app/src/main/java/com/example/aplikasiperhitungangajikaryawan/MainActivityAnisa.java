package com.example.aplikasiperhitungangajikaryawan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivityAnisa extends AppCompatActivity {
    Button btnGaji, btnPetunjuk, btnTentang, btnExit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_anisa);

        btnGaji = findViewById(R.id.btnGaji);
        btnPetunjuk = findViewById(R.id.btnPetunjuk);
        btnTentang = findViewById(R.id.btnTentang);
        btnExit = findViewById(R.id.btnExit);

        btnGaji.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivityAnisa.this, GajiKaryawanActivityAnisa.class);
                startActivity(intent);
            }
        });

        btnPetunjuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivityAnisa.this, PetunjukPenggunaanActivityAnisa.class);
                startActivity(intent);
            }
        });

        // 3. Aksi ketika tombol "Tentang" diklik (Pindah ke Halaman Tentang Aplikasi)
        btnTentang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivityAnisa.this, TentangAplikasiActivityAnisa.class);
                startActivity(intent);
            }
        });

        // 4. Aksi ketika tombol "Exit" diklik (Keluar dari aplikasi)
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                System.exit(0);
            }
        });
    }
}