package com.example.aplikasiperhitungangajikaryawan;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class PetunjukPenggunaanActivityAnisa extends AppCompatActivity {

    Button btnKembaliPetunjuk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petunjuk_penggunaan_anisa);

        btnKembaliPetunjuk = findViewById(R.id.btnKembaliPetunjuk);

        // Aksi tombol kembali ke Menu Utama
        btnKembaliPetunjuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}