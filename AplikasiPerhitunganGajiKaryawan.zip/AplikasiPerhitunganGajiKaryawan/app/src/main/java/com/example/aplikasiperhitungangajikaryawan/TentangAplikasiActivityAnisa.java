package com.example.aplikasiperhitungangajikaryawan;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class TentangAplikasiActivityAnisa extends AppCompatActivity {

    Button btnKembaliTentang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_aplikasi_anisa);

        btnKembaliTentang = findViewById(R.id.btnKembaliTentang);

        // Aksi tombol kembali ke Menu Utama
        btnKembaliTentang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}